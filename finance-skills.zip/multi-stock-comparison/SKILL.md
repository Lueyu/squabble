---
name: multi-stock-comparison
description: 对两家及以上上市公司或股票进行横向研究，覆盖大盘与板块、外围市场、供应链、重要新闻与监管、商业模式、经营财务、成长、预期、估值、股价、组合以及 A/H 股与跨上市地相对价值。适用于公司比较、选股、财报或估值对比、股价与事件复盘、供应链或监管分析、组合适配、配对交易、H 股相对价值，以及需要 HTML 报告、高级金融图表或可复核多维报告的任务。
---

# 多股票横向研究

## 第一步：设置 delivery_mode

在检索、分析、起草或生成图表前，必须先读取 `references/html-report-delivery.md`，并把本次任务锁定为且仅为以下一种状态：

- `delivery_mode=TEXT`：仅当第 1 节的四项简单问题条件**全部满足**；
- `delivery_mode=HTML_REPORT`：任一简单条件不满足、无法确定，或用户要求 HTML 报告时。

三家以上比较、两家公司多维比较、全面股票对比、竞品分析、投资二选一、财报比较、估值比较、**任何股价表现/涨跌/事件反应分析**、组合适配、配对交易、完整报告、可复核引用、可分享交付物，以及需要真实横向表/情景/图示/多章节导航的任务，直接设为 `HTML_REPORT`。用户没有明确要求文档、query 很短、聊天界面支持 Markdown，均不是选择 `TEXT` 的理由。

模式一经设定，不得因为文档创建较慢、命令复杂、认证或权限问题从 `HTML_REPORT` 降级为 `TEXT`；阻塞按未完成状态处理。`TEXT` 模式不得生成 HTML 图表组件、SVG 图示、SVG/Mermaid/PlantUML、分栏、高亮块或富样式表格；一旦实际生成任一高级组件，立即把模式升级为 `HTML_REPORT`，且不得回退。

在工作记录中建立交付清单，并在开始时运行 `scripts/delivery_gate.py --phase plan`。`HTML_REPORT` 模式在完整正文起草和高级组件生成前，先规划报告骨架与输出路径；最终生成 HTML、确认文件完整后运行 `scripts/delivery_gate.py --phase final`。未通过最终门禁不得把任务表述为完成。

## 初始化与比较范围

设置 `delivery_mode` 后读取 `references/research-standards.md`，锁定比较对象、用户要做的判断、信息截止日、比较期间、币种、业务层级和估值时点。凡需检索外部金融数据，同时读取 `references/capability-financial-data-search.md`。

## 默认核心财务金融数据底座

除非能确认核心财务金融数据与用户问题无关，否则读取 `references/core-financial-snapshot.md`，为全部比较对象建立同一估值日和可比报告期的紧凑横向快照。默认设置 `core_financial_snapshot.status=included`，用一张表覆盖市场数据、估值，以及至少两个经营财务类别；缺失值明确标注，不补造。

只有符合该文件明确列出的不相关条件时，才可设置 `status=not_relevant`，并记录标准原因代码和具体理由。不得以篇幅、取数难度、制作成本、已有定性结论或部分数据缺失为理由省略。快照表放在核心结论之后、详细分析之前，不逐格复述，也不据此增加无关章节或图表。

## 内容准入与写作质量

所有 `HTML_REPORT` 任务和超过三段的 `TEXT` 任务都必须读取 `references/writing-quality.md`。默认使用 `standard` 文档档位；只有用户明确要求深度研究，或核心判断确实需要更多相互独立的证据链时，才使用 `deep_dive` 并记录理由。文档存在不构成增加篇幅的理由。

研究完成、正式起草前建立质量清单：先登记 `core_financial_snapshot`，再为每个拟保留章节说明它怎样改变用户判断、带来什么未重复的新信息、使用哪些可复核证据，以及读者看完应得到什么结论。任一项不能回答就删除该章节，不把低质量内容写入文档“供参考”。任何候选图表同时进入 `visual_plan`，逐图说明信息任务、为何优于文字/表格、证据、读者结论和去重组；按 `one_pager/standard/deep_dive` 默认最多保留 1/3/5 个视觉家族，超过时记录不可压缩理由。按 `references/script-usage.md` 运行 `scripts/editorial_gate.py --phase plan`；写入并确认生成文件完整后完成压缩检查，再运行 `--phase final`。两个阶段未通过均不得结束任务。

只要选择 `capability-price-behavior.md`，质量清单必须设置 `price_analysis=true`，并默认设置 `kline_plan.status=included`。按 `advanced-html-visuals.md` 原则上为全部决策相关标的生成同窗口、同频率、同复权定义的 K 线图；样本过大时按该文件保留焦点/决策相关子集，并用统一基期图表覆盖全样本。只有符合该文件明确列出的不适用条件时，才可设置 `not_applicable`，并记录标准原因代码和具体理由；不得以篇幅、制作成本或“已有收益表”为理由省略。

## 选择能力

先把 query 拆成比较问题，再选择能回答问题的最小能力集合。每个能力必须同时讨论所有公司，并解释差异的原因与含义。

| 比较问题 | 读取能力 |
|---|---|
| 默认核心财务金融数据，以及财务报表、经营指标、估值、行情、一致预期或行业数据的检索与对齐 | `references/core-financial-snapshot.md` + `references/capability-financial-data-search.md` |
| 大盘环境、概念/板块表现、风格与流动性、外围美股/日韩及跨市场传导 | `references/capability-market-sector-global-context.md` |
| 行业位置、产品定位、客户结构、份额与竞争格局 | `references/capability-market-position.md` |
| 供应链位置与风险、公司近期重要新闻、国际事件、监管政策与执法 | `references/capability-supply-chain-news-regulation.md` |
| 如何收费、利润池、单位经济、商业模式和护城河 | `references/capability-business-model.md` |
| 收入、分部、量价、利润率、费用和经营 KPI | `references/capability-operating-fundamentals.md` |
| 现金流、资产负债表、资本投入、ROIC 和盈利质量 | `references/capability-financial-quality.md` |
| 增长空间、约束、研发、产能、渠道和执行结果 | `references/capability-growth-execution.md` |
| 一致预期、beat/miss、预测修正和市场假设 | `references/capability-expectations.md` |
| 相对估值、历史估值、SOTP、隐含假设与敏感性 | `references/capability-valuation.md` |
| 股价、相对收益、波动、事件反应和市场定价 | `references/capability-price-behavior.md` |
| 催化剂、结构性风险、证伪条件和情景赔率 | `references/capability-risks-catalysts.md` |
| 组合分散、因子暴露、流动性、对冲和配对交易 | `references/capability-portfolio-fit-pair-trade.md` |
| A/H 股溢价、H 股折溢价、跨上市地相对价值与所谓套利可执行性 | `references/capability-cross-listing-ah-relative-value.md` |
| 相对投资逻辑、领先指标、状态和版本变化 | `references/capability-relative-thesis-monitoring.md` |

## 默认组合

用户问题宽泛时使用以下默认组合，避免遗漏决定投资判断的维度：

- **比较几只股票、全面股票对比**：先执行下述领域相关性扫描，再用行业位置 + 商业模式 + 经营基本面 + 财务质量 + 成长执行 + 市场预期 + 估值 + 风险催化剂；加入筛中命中的市场、新闻、供应链或跨上市地能力。
- **竞品分析、业务能力对比**：行业位置 + 商业模式 + 经营基本面 + 财务质量 + 成长执行；涉及上下游、地缘或监管时增加供应链/新闻/监管，关心投资时再加预期、估值和风险催化剂。
- **哪家公司更值得投资、选一个标的**：使用全面股票对比；近期交易、事件驱动或股价归因时增加大盘/板块/外围、新闻监管和股价表现。
- **产品、客户或市场地位比较**：行业位置 + 商业模式 + 成长执行；若用户关心盈利兑现，再加经营基本面。
- **基本面或财务比较**：经营基本面 + 财务质量 + 成长执行。
- **估值比较**：经营基本面 + 财务质量 + 市场预期 + 估值，避免只比较孤立倍数。
- **财报比较**：经营基本面 + 财务质量 + 市场预期；询问财报后反应时增加股价表现。
- **近期表现、事件复盘、市场为何选择其中一家**：大盘/板块/外围 + 公司/供应链/监管新闻 + 股价表现 + 市场预期。
- **产业链或地缘风险比较**：行业位置 + 供应链/新闻/监管 + 风险催化剂；需要量化盈利影响时增加经营基本面和情景。
- **加入组合、二选一配置**：全面股票对比 + 组合适配；用户未提供现有组合时，只比较标的自身风险暴露并明确限制。
- **配对交易、做多一个做空一个**：商业模式 + 经营基本面 + 市场预期 + 估值 + 风险催化剂 + 组合适配与配对交易。
- **A/H 股、H 股折溢价或套利机会**：跨上市地/AH 相对价值 + 金融数据检索 + 股价表现 + 风险催化剂；不得只凭价差称为套利。
- **持续跟踪相对胜负**：选择原论点涉及的能力，再加相对论点跟踪；不重复无关模块。
- **只比较一个明确变量**：只选择直接相关能力，但仍执行可比性审计。

输出长短不改变能力选择。一页纸只压缩证据和表达，不删除必要维度。

## 领域相关性扫描

全面比较、投资二选一、一页纸、近期表现复盘、组合适配和配对交易在选能力前读取 `references/report-domain-routing.md`，扫描以下领域：大盘、概念/板块、供应链位置、公司近期重要新闻、供应链/国际新闻、图表、监管新闻、外围美股/日韩、A/H 或 H 股相对价值。仅在以下任一条件成立时把领域写入正文：用户明确询问；该领域解释公司间差异；会改变盈利、预期、估值、股价或风险；能形成可验证的催化剂/证伪条件。未命中时不要为了齐全增加市场播报或新闻堆砌。

“近期”默认使用截至日向前 90 个自然日，并覆盖各公司最近一次财报以来的重大事项；短线/事件驱动问题按用户窗口收窄。每条新闻区分事件发生时间、首次发布时间和对目标市场可交易的时间。大盘、板块和外围市场只保留具有明确传导路径的部分。只要比较对象存在 A/H 双重上市，至少检查是否有显著折溢价或交易制度差异；仅在其改变结论时展开。

## 横向执行

1. 先完成核心财务金融快照，再为其他能力定义相同指标、期间、币种、单位和业务层级。
2. 涉及外部金融数据时，优先通过 `/seed_finance_search` 同批检索所有公司的核心快照和其他同类数据；保留查询、字段定义、期间、快照日和来源信息，并按 `references/capability-financial-data-search.md` 处理异常与降级。
3. 每个能力按 `横向判断 → 关键证据 → 差异机制 → 为什么重要 → 边界/反例` 形成分析对象。
4. 禁止先写完公司 A 再写公司 B；每一节都逐维度同时比较全部对象。
5. 最后寻找能解释至少三个差异的因果主线：

```text
行业角色与客户 → 商业模式与利润池 → 经营/财务结果
→ 增长约束与市场预期 → 估值 → 风险与催化剂
```

一条主线会掩盖重要反例时使用两条；概括标签必须有定义、证据和适用边界。

## 可比性与审计

时间对齐优先级为：共同 TTM → 共同自然年或连续 12 个月 → 各自最新完整财年。只能获得错期、不同币种或不同业务层级数据时，明确标记并取消不成立的排名。

三家公司以上、混合口径、量化排名或衍生计算时建立证据账本，并按 `references/script-usage.md` 运行 `scripts/audit_ledger.py`。简单定性比较无需制造账本。

反向 DCF 比较需要可复算时，按 `references/script-usage.md` 分别运行 `scripts/reverse_dcf.py`，保持企业价值桥、变量定义和估值时点一致。脚本输出属于计算方法，不是事实来源。

A/H 或其他跨上市地价差需要可复算时，按 `references/script-usage.md` 运行 `scripts/ah_premium.py`。脚本只计算同步折溢价、成本假设和执行条件筛查，不证明存在可执行套利。

选择股价表现能力时必须读取 `references/advanced-html-visuals.md` 并默认生成 K 线；任何能力准备生成图表、图解或高级视觉时也必须读取该文件，先在表格、HTML 图表组件、SVG/Mermaid 图示 与段落之间逐图选型。K 线不得用收盘价伪造 OHLC；多象限分析不得用未解释的综合分数制造伪精确；相同 `redundancy_group` 只能保留一个视觉家族。图形先按 `advanced-html-visuals.md` 写自然语言视觉说明，再选择适合的 HTML、SVG 或图片制作方式。交付门禁的输入合同见 `references/script-usage.md`：

- 交付模式计划/完成态校验：`scripts/delivery_gate.py`
- 章节准入与最终压缩校验：`scripts/editorial_gate.py`
- A/H 折溢价与执行条件筛查：`scripts/ah_premium.py`

## 交付

严格执行任务开始时已经锁定的 `delivery_mode`。`TEXT` 只在四项简单条件全部满足时直接回答。`HTML_REPORT` 必须把通过内容准入门禁的主要比较写成金融风格的自包含 HTML 报告，在聊天中只给一至三句最核心结论和 HTML 文件链接。

先用 Markdown 完成读者版正文。图像按视觉说明制作并确认数据准确；图表 HTML 用独立一行 `{{embed:相对路径.html}}` 插入；SVG/PNG 图可用 Markdown 图片语法插入。运行 `python3 scripts/render_html_report.py <读者版正文.md> --output <报告.html>`，然后核对生成文件包含预期正文、表格、引用和图表嵌入。修改后重新生成并核对。浏览器预览可按需进行，不作为交付条件。

**最终交付硬门禁：**交付前先运行 `scripts/editorial_gate.py --phase final`，确认结论前置、核心财务金融快照已包含或有可审计的不相关理由、低质量内容已删除、无重复结论、无新闻堆砌；逐图确认信息任务、预算、去重、来源/单位、文字结论和图表嵌入，再更新交付清单并运行 `scripts/delivery_gate.py --phase final`。`HTML_REPORT` 只有在质量门禁通过、HTML 文件已生成且完整性校验通过时才会通过。完整规则见 `references/html-report-delivery.md`。

结论先回答“本质差异是什么、为什么重要”，再给决定结论的证据、不可比项、反例和验证点。不要擅自给目标价或买卖指令。完整投资研究最后一行使用：`公开资料仅供信息参考，不构成投资建议。`
