#!/usr/bin/env python3
"""Shared V3 mode-aware report linter. Stdlib only."""

import argparse
import json
import re
from pathlib import Path


COMMON_BANNED = [
    r"\bTODO\b",
    r"\bTBD\b",
    r"待补充",
    r"保证收益",
    r"稳赚(?:不赔)?",
    r"必然?(?:上涨|下跌)",
    r"强烈推荐(?:买入|卖出)",
    r"建议(?:立即|马上)?(?:买入|卖出|加仓|减仓)",
    r"目标价\s*[:：]?\s*[￥$¥]?\d",
    r"仓位\s*[:：]?\s*\d+(?:\.\d+)?%",
]
SENSITIVE = [
    r"\b\d{17}[\dXx]\b",
    r"\b\d{16,19}\b",
    r"\b1[3-9]\d{9}\b",
]
FACT_RE = re.compile(r"\{fact:([A-Za-z0-9_.-]+)\}")
AUDIT_TAG = re.compile(r"\[(?:一手|库|用户|推算|待核|阈值)·[^\]]+\]")
INVALID_REFUSAL_RE = re.compile(
    r"(?:无法|不能|不足以)(?:完成|分析|判断|估值).{0,30}"
    r"(?:因此|所以)?(?:停止|不再|无法继续|仅列|只能列)",
    re.I,
)
GAP_LINE_RE = re.compile(r"(?:缺少|缺失|未知|unknown|待获取|无法取得|待核对)", re.I)
CONCLUSION_RE = re.compile(r"(?:核心判断|直接结论|结论是|总体判断|我们判断)", re.I)
FCF_PROXY_RE = re.compile(
    r"(?:FCF|自由现金流).{0,40}(?:经营利润|operating\s+profit)"
    r".{0,80}(?:折旧|非现金|non[- ]cash).{0,80}(?:资本开支|CapEx)",
    re.I | re.S,
)
RIGHTS_FIXED_DILUTION_RE = re.compile(
    r"(?:版权费|版权成本|内容分成|创作者分成|royalt(?:y|ies)|content\s+costs?)"
    r".{0,50}(?:固定成本|fixed\s+cost).{0,40}(?:摊薄|dilut|leverage)",
    re.I | re.S,
)


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))


def sections(text):
    found = {}
    current = None
    for line in text.splitlines():
        match = re.match(r"^##\s+(.+?)\s*$", line)
        if match:
            current = re.sub(r"^\[[^\]]+\]\s*", "", match.group(1)).strip()
            found[current] = []
        elif current is not None:
            found[current].append(line)
    return {name: "\n".join(body).strip() for name, body in found.items()}


def find_section(parsed, aliases):
    for alias in aliases:
        if alias in parsed:
            return alias, parsed[alias]
    return None, ""


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("report")
    parser.add_argument("facts")
    parser.add_argument(
        "--config",
        default=str(Path(__file__).resolve().parent.parent / "config" / "runtime.json"),
    )
    args = parser.parse_args()
    try:
        text = Path(args.report).read_text(encoding="utf-8")
        facts = load(args.facts)
        config = load(args.config)
    except Exception as error:
        print(f"ERROR: cannot load input: {error}")
        return 2

    errors = []
    warnings = []
    mode = facts.get("meta", {}).get("mode")
    mode_config = config.get("modes", {}).get(mode)
    if not mode_config:
        errors.append(f"unsupported or missing mode: {mode}")
        mode_config = {}
    patterns = COMMON_BANNED + config.get("banned_patterns", [])
    for pattern in patterns:
        if re.search(pattern, text, re.I):
            errors.append(f"banned pattern: {pattern}")
    if config.get("privacy_scan"):
        for pattern in SENSITIVE:
            if re.search(pattern, text):
                errors.append(f"sensitive data pattern: {pattern}")

    refs = set(FACT_RE.findall(text))
    known = {
        claim.get("claim_id")
        for claim in facts.get("claims", [])
        if isinstance(claim, dict) and claim.get("claim_id")
    }
    for ref in sorted(refs - known):
        errors.append(f"unknown fact binding: {ref}")
    main_text = re.split(r"^##\s+(?:附录|来源账|证据附录)", text, maxsplit=1, flags=re.M)[0]
    if AUDIT_TAG.search(main_text):
        errors.append("machine source tag exposed in main text")
    if INVALID_REFUSAL_RE.search(text):
        errors.append("invalid global refusal: use local capability/unknown instead")
    if FCF_PROXY_RE.search(text):
        errors.append("FCF uses operating-profit proxy instead of cash-flow statement")
    if RIGHTS_FIXED_DILUTION_RE.search(text):
        errors.append("variable rights/content cost treated as fixed-cost dilution")

    for item in warnings:
        print("WARNING:", item)
    for item in errors:
        print("ERROR:", item)
    print(
        f"SUMMARY errors={len(errors)} warnings={len(warnings)} "
        f"mode={mode} fact_bindings={len(refs)}"
    )
    return 1 if errors else 0


if __name__ == "__main__":
    raise SystemExit(main())
